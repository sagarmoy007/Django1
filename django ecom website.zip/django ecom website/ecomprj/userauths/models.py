from django.db import models
from django.contrib.auth.models import AbstractUser
from django.contrib.auth import get_user_model
from django.contrib.auth.models import AbstractBaseUser




user=get_user_model()
# Create your models here.

class CustomUser(AbstractBaseUser):
    ...
    class Meta:
        app_label = 'userauths'

class User(AbstractUser):
    # username=None
    email=models.EmailField(unique=True,null=False)
    username=models.CharField(max_length=100)
    
    USERNAME_FIELD="email"
    REQUIRED_FIELDS='username'

    def __self__(self):
        return self.username
