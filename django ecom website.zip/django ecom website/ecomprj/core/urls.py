from django.urls import path
from core.views import index
from . import views
app_name="core"
urlpatterns=[
    path("urls/", index)
]

# # Correcting import statement
# from django.urls import path
# from core.views import index

# # Correcting namespace definition
# app_name = "core"

# # Correcting urlpatterns
# urlpatterns = [
#     path("", index, name="index"),  # Assuming index is the name of your view function
# ]
